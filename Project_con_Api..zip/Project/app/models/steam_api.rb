class SteamApi
    require 'net/http'
  
    def initialize(game_id)
        @url_base = URI("https://steam2.p.rapidapi.com/appDetail/#{game_id}")
        @http = Net::HTTP.new(@url_base.host, @url_base.port)
        @http.use_ssl = true
        @request = Net::HTTP::Get.new(@url_base)
        @request["X-RapidAPI-Key"] = '0035a6aeedmshf67c280deef2946p154266jsn9f8edec06fc1'
        @request["X-RapidAPI-Host"] = 'steam2.p.rapidapi.com'
    end
  
    def search(game_name)
        url = URI("https://steam2.p.rapidapi.com/search/#{game_name}")
        request = Net::HTTP::Get.new(url)
        request["X-RapidAPI-Key"] = '0035a6aeedmshf67c280deef2946p154266jsn9f8edec06fc1'
        request["X-RapidAPI-Host"] = 'steam2.p.rapidapi.com'
        response = @http.request(request)
        JSON.parse(response.read_body)
      end
      
  
    def app_detail(app_id)
      url = URI("#{@url_base}/appDetail/#{app_id}")
      @request.url = url
      response = @http.request(@request)
      JSON.parse(response.body)
    end
  end
  