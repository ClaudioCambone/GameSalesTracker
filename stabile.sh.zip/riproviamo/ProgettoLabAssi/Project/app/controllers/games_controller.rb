class GamesController < ApplicationController

  before_action :authenticate_user!, except: [:index, :show]

  #http_basic_authenticate_with name: "user", password: "user", except: [:index, :show]

  def index
    @games = Game.all
  end

  def show 
    @game = Game.find(params[:id])
  end

  def new 
    @game = Game.new
  end

  def create 
    @game = Game.new(game_params)
    if @game.save
      redirect_to @game
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
    @game = Game.find(params[:id])
  end
  
  def update
    @game = Game.find(params[:id])
    if @game.update(game_params)
      redirect_to @game
    else
      render :new, status: :unprocessable_entity
    end
  end

  def destroy
    @game = Game.find(params[:id])
    @game.destroy

    redirect_to root_path, status: :see_other
  end

  def search
    steam_api = SteamApi.new
    cheap_shark_api = CheapSharkApi.new
    games = steam_api.search(params[:game_name])
  
    @games = games.map do |game|
      price = cheap_shark_api.find_price_by_title(game["title"])
      # Aggiungi questa linea per stampare il prezzo trovato (o la sua mancanza).
      puts "Prezzo trovato per #{game["title"]}: #{price}"
      game.merge("price" => price || "N/A")
    end
  
    render :search_results
  end
  



  private 
  def game_params
    params.require(:game).permit(:title, :body, :status)
  end

end

