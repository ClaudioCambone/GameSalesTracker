require 'net/http'
require 'json'

class CheapSharkApi
    def initialize
      @url_base = URI("https://cheapshark-game-deals.p.rapidapi.com/deals")
      @http = Net::HTTP.new(@url_base.host, @url_base.port)
      @http.use_ssl = true
      @rapid_key = '0035a6aeedmshf67c280deef2946p154266jsn9f8edec06fc1'  # Usiamo la tua chiave
    end
  
    def find_price_by_title(title)
        request_uri = @url_base.dup
        request_uri.query = URI.encode_www_form({
          "title" => title,
          "pageSize" => 60
        })
      
        request = Net::HTTP::Get.new(request_uri)
        request["X-RapidAPI-Key"] = @rapid_key
        request["X-RapidAPI-Host"] = 'cheapshark-game-deals.p.rapidapi.com'
      
        response = @http.request(request)
        parsed_response = JSON.parse(response.body)
      
        # Trova l'hash che corrisponde al titolo del gioco
        game_data = parsed_response.find { |game| game["title"] == title }
      
        # Restituisci il prezzo se l'hash corrispondente è stato trovato
        game_data ? game_data["salePrice"] : nil
      end
      
    
end