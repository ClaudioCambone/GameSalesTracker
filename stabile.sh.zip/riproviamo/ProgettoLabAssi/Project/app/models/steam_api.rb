require 'net/http'
require 'json'

class SteamApi
    def initialize
        @url_base = URI("https://steam2.p.rapidapi.com/")
        @http = Net::HTTP.new(@url_base.host, @url_base.port)
        @http.use_ssl = true
        @rapid_key = '0035a6aeedmshf67c280deef2946p154266jsn9f8edec06fc1'
    end

    def search(game_name)
        game_name_encoded = URI.encode_www_form_component(game_name)
        puts "Game name: #{game_name}"
        puts "Encoded game name: #{game_name_encoded}"

        url = URI.join(@url_base, "search/#{game_name_encoded}/page/1")
        puts "Rapid Key: #{@rapid_key}"
        puts "URL: #{url}"
        request = Net::HTTP::Get.new(url)
        request["X-RapidAPI-Key"] = @rapid_key
        request["X-RapidAPI-Host"] = 'steam2.p.rapidapi.com'
  
        begin
            response = @http.request(request)
            puts "Response body: #{response.body}" # aggiungi questa riga per vedere la risposta prima del parsing
            @games = JSON.parse(response.body)
            puts "Games: #{@games.inspect}"
            puts "URL base: #{@url_base}"
        rescue => e
            puts "Error: #{e}"
        end

        return @games
    end





  

  def app_detail(app_id)
    url = URI(@url_base + "appDetail/#{app_id}")
    request = Net::HTTP::Get.new(url)
    request["X-RapidAPI-Key"] = '0035a6aeedmshf67c280deef2946p154266jsn9f8edec06fc1'
    request["X-RapidAPI-Host"] = 'steam2.p.rapidapi.com'
    
    response = @http.request(request)
    JSON.parse(response.body)
  end
end

  